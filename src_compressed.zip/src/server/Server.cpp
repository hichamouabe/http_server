#include "Server.hpp"
#include <sstream>
#include <sys/wait.h>
#include <signal.h>
Server::Server() {
	epfd = epoll_create1(0);
	loadMimeTypes("conf/mime.types");
	if (epfd == -1)
		throw std::runtime_error("epoll_create1 failed");
}

Server::~Server() {
	for (size_t i = 0; i < listenfd.size(); i++)
		close(listenfd[i]);
	for (std::map<int, Client*>::iterator it = clients.begin(); it != clients.end(); ++it) {
		close(it->first);
		delete it->second;
	}
	close(epfd);
}


void Server::setSocketTimeout(int fd) {
    struct timeval tv;
    tv.tv_sec = SOCKET_TIMEOUT;
    tv.tv_usec = 0;

    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
}


void	Server::setup(const std::vector<ServerConfig>& configs) {
	_configs = configs;
	std::map<std::string, int> default_servers;  // ← ADD THIS
    
    // ← ADD THIS VALIDATION BLOCK
for (size_t i = 0; i < _configs.size(); i++) {
    if (_configs[i].server_names.empty()) {
        // Loop through each listen socket for this config
        for (size_t j = 0; j < _configs[i].listen_sockets.size(); j++) {
            int port = _configs[i].listen_sockets[j].second;
            
            // Convert port to string without to_string
            std::ostringstream oss;
            oss << port;
            std::string port_key = oss.str();
            
            default_servers[port_key]++;
            
            if (default_servers[port_key] > 1) {
                throw std::runtime_error(
                    "Error: Multiple server blocks without server_name on port " + port_key
                );
            }
        }
    }
}
	std::map<std::string, int> bound;

	for (size_t i = 0; i < _configs.size(); i++) {
		for (size_t j = 0; j < _configs[i].listen_sockets.size(); j++) {
			std::string host = _configs[i].listen_sockets[j].first;
			int	port = _configs[i].listen_sockets[j].second;

			std::ostringstream oss;
			oss << host << ":" << port;
			std::string key = oss.str();

			if (bound.find(key) == bound.end()) {
				int fd = createListenSocket(host, port);
				listenfd.push_back(fd);
				bound[key] = fd;
				addToEpoll(fd);
				std::cout << "[LISTEN]" << key << " fd=" << fd << std::endl;
			}
			int lfd = bound[key];

			// ✅ CHANGED: Store ALL configs for this listening fd
			_fd_to_configs[lfd].push_back(i);
		}
	}
}

void	Server::acceptClients(int listen_fd) {
	while (true) {
		int clientfd = accept(listen_fd, NULL, NULL);
		if (clientfd < 0) {
			if (errno == EAGAIN || errno == EWOULDBLOCK) break;
			return ;
		}
		setSocketTimeout(clientfd);
		setNonBlocking(clientfd);
		addToEpoll(clientfd);
		Client* cl = new Client(clientfd);
		cl->setListenFd(listen_fd);
		cl->updateActivityTime();  // ← ADD THIS LINE
		clients.insert(std::make_pair(clientfd, cl));
		std::cout << "[ACCEPT] client fd=" << clientfd << std::endl;
	}
}

void Server::disconnect(int fd) {
    Client* c = clients[fd];
    
    // --- NEW CGI CLEANUP ---
    if (c->cgi_pid > 0) {
        std::cout << "[CGI] Killing stuck/abandoned CGI process PID=" << c->cgi_pid << std::endl;
        kill(c->cgi_pid, SIGKILL);
        waitpid(c->cgi_pid, NULL, 0); // Prevent zombie process
    }
    if (c->cgi_fd > 0) {
        epoll_ctl(epfd, EPOLL_CTL_DEL, c->cgi_fd, NULL);
        close(c->cgi_fd);
        cgi_clients.erase(c->cgi_fd); // Remove from CGI map
    }
    // -----------------------

    epoll_ctl(epfd, EPOLL_CTL_DEL, fd, NULL);
    close(fd);
    delete c;
    clients.erase(fd);
    std::cout << "[DISCONNECT] fd=" << fd << std::endl;
}

